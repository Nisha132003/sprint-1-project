package com.tns.Employee.Service;

import java.time.LocalDate;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Employee
{
    @Id
    @Column(name="Eid")
	private int id;
    @Column(name="Ename")
    private String name;
    @Column(name="dob")
    private LocalDate date;
    @Column(name="Salary")
    private float salary;
    @Column(name="Eaddress")
    private String address;
    @Column(name="Designation")
    private String designation;
    @Column(name="Shop_id")
    private String sid;
    
    
	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}

	

	

	public Employee(int id, String name, LocalDate date, float salary, String address, String designation, String sid) {
		super();
		this.id = id;
		this.name = name;
		this.date = date;
		this.salary = salary;
		this.address = address;
		this.designation = designation;
		this.sid = sid;
	}





	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public LocalDate getDate() {
		return date;
	}

	public void setDate(LocalDate date) {
		this.date = date;
	}

	public float getSalary() {
		return salary;
	}

	public void setSalary(float salary) {
		this.salary = salary;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

	public String getSid() {
		return sid;
	}

	public void setSid(String sid) {
		this.sid = sid;
	}

	@Override
	public String toString() {
		return "Employee [id=" + id + ", name=" + name + ", salary=" + salary + ", address=" + address
				+ ", designation=" + designation + ", sid=" + sid + "]";
	}

	
    
}
