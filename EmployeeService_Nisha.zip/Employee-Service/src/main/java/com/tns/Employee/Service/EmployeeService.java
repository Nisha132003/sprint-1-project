package com.tns.Employee.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional
public class EmployeeService {
	
		@Autowired
		private EmployeeRepository repo;
		
		public void save(Employee employ)
		{
			repo.save(employ);
		}
		
		public List<Employee> getAllEmployee()
		{
			return repo.findAll();
		}
		
		public Employee getEmployeeById(Integer id) 
		{
			return repo.findById(id).orElse(null);
		}
		
		public void deleteEmployee(Integer id)
		{
			repo.deleteById(id);
		}

		public void updateEmployee(Integer id , Employee updatedEmployee)
		{
			Employee existingEmployee = repo.findById(id).orElse(null);
			if (existingEmployee != null)
			{
				existingEmployee.setName(updatedEmployee.getName());
				existingEmployee.setDate(updatedEmployee.getDate());
				existingEmployee.setSalary(updatedEmployee.getSalary());
				existingEmployee.setAddress(updatedEmployee.getAddress());
				existingEmployee.setDesignation(updatedEmployee.getDesignation());
				existingEmployee.setSid(updatedEmployee.getSid());
				repo.save(existingEmployee);
			}
		}
}
